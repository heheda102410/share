﻿// TestDialog.cpp: 实现文件
//

#include "pch.h"
#include "StuInfoSystem.h"
#include "afxdialogex.h"
#include "TestDialog.h"


// TestDialog 对话框

IMPLEMENT_DYNAMIC(TestDialog, CDialogEx)

TestDialog::TestDialog(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TESTDIALOG, pParent)
{

}

TestDialog::~TestDialog()
{
}

void TestDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(TestDialog, CDialogEx)
	ON_BN_CLICKED(IDC_CONNECTBUTTON, &TestDialog::OnBnClickedConnectbutton)
END_MESSAGE_MAP()


// TestDialog 消息处理程序


void TestDialog::UpdateList()
{
	CString str;
	//m_list.DeleteAllItems();
	/*for (int i = 0; i < Info.size(); i++) {
		m_list.InsertItem(i, Info[i].m_name.c_str());
		m_list.SetItemText(i, 1, Info[i].m_sex.c_str());

		str.Format(TEXT("%d"), Info[i].m_class_);
		m_list.SetItemText(i, 2, str);

		str.Format(TEXT("%.1f"), Info[i].m_english);
		m_list.SetItemText(i, 3, str);

		str.Format(TEXT("%.1f"), Info[i].m_chinese);
		m_list.SetItemText(i, 4, str);

		str.Format(TEXT("%.1f"), Info[i].m_math);
		m_list.SetItemText(i, 5, str);
	}*/
}
void TestDialog::OnBnClickedConnectbutton()
{
	// TODO: 在此添加控件通知处理程序代码
	if (SQL.Connect_MySQL()) {
		Info = SQL.Get_All_Info();
		
	}
	else {
		return;
	}
}