#pragma once
class StuInfo
{
public:
    string m_name;
    string m_sex;
    int m_class_;
    double m_english;
    double m_chinese;
    double m_math;

    StuInfo();
    StuInfo(string name, string sex, int class_, double english, double chinese, double math);
};

