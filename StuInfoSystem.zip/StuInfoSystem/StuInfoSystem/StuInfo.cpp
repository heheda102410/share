#include "pch.h"
#include "StuInfo.h"

StuInfo::StuInfo()
{
}

StuInfo::StuInfo(string name, string sex, int class_, double english, double chinese, double math)
{
    m_name = name;
    m_sex = sex;
    m_class_ = class_;
    m_english = english;
    m_chinese = chinese;
    m_math = math;
}
