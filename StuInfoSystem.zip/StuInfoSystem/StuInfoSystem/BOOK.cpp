﻿// BOOK.cpp: 实现文件
//

#include "pch.h"
#include "StuInfoSystem.h"
#include "afxdialogex.h"
#include "BOOK.h"


// BOOK 对话框

IMPLEMENT_DYNAMIC(BOOK, CDialogEx)

BOOK::BOOK(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_BOOK, pParent)
{

}

BOOK::~BOOK()
{
}

void BOOK::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(BOOK, CDialogEx)
	ON_BN_CLICKED(IDC_CONNBUTTON, &BOOK::OnBnClickedConnbutton)
END_MESSAGE_MAP()


// BOOK 消息处理程序


void BOOK::OnBnClickedConnbutton()
{
	// TODO: 在此添加控件通知处理程序代码
	if (SQL.Connect_MySQL()) {
		Info = SQL.Get_All_Info();

	}
	else {
		return;
	}
}
