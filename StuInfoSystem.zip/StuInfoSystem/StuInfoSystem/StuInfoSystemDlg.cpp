﻿
// StuInfoSystemDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "StuInfoSystem.h"
#include "StuInfoSystemDlg.h"
#include "afxdialogex.h"

#include "SeekDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
#include "InfoDlg.h"
#include "TestDialog.h"
#include "Book.h"

// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CStuInfoSystemDlg 对话框



CStuInfoSystemDlg::CStuInfoSystemDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_STUINFOSYSTEM_DIALOG, pParent)
	, m_high(0)
	, m_low(0)
	, m_avg(_T(""))
	, m_pass(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CStuInfoSystemDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST3, m_list);
	DDX_Control(pDX, IDC_COMBO1, m_class);
	DDX_Control(pDX, IDC_SUBJECTCOMBO, m_subject);
	//  DDX_Text(pDX, IDC_AVGEDIT, m_avg);
	DDX_Text(pDX, IDC_HIGHEDIT, m_high);
	DDX_Text(pDX, IDC_LOWEDIT, m_low);
	//  DDX_Text(pDX, IDC_PASSEDIT, m_pass);
	DDX_Text(pDX, IDC_AVGEDIT, m_avg);
	DDX_Text(pDX, IDC_PASSEDIT, m_pass);
	//  DDX_Control(pDX, IDC_SORTCOMBO1, m_ruleAsc);
	//  DDX_Control(pDX, IDC_SORTCOMBO2, m_ruleDesc);
	DDX_Control(pDX, IDC_SORTCOMBO1, m_rule1);
	DDX_Control(pDX, IDC_SORTCOMBO2, m_rule2);
}

BEGIN_MESSAGE_MAP(CStuInfoSystemDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_INPUTDATA, &CStuInfoSystemDlg::OnBnClickedInputdata)
	ON_BN_CLICKED(IDC_INSERTDATA, &CStuInfoSystemDlg::OnBnClickedInsertdata)
	ON_BN_CLICKED(IDC_DELDATA, &CStuInfoSystemDlg::OnBnClickedDeldata)
	ON_BN_CLICKED(IDC_MODIFYDATA, &CStuInfoSystemDlg::OnBnClickedModifydata)
	ON_BN_CLICKED(IDC_FINDDATA, &CStuInfoSystemDlg::OnBnClickedFinddata)
	ON_BN_CLICKED(IDC_CALCULATEBUTTON, &CStuInfoSystemDlg::OnBnClickedCalculatebutton)
	ON_CBN_SELCHANGE(IDC_SORTCOMBO1, &CStuInfoSystemDlg::OnCbnSelchangeSortcombo1)
	ON_CBN_SELCHANGE(IDC_SORTCOMBO2, &CStuInfoSystemDlg::OnCbnSelchangeSortcombo2)
	ON_BN_CLICKED(IDC_EXIT, &CStuInfoSystemDlg::OnBnClickedExit)
	ON_BN_CLICKED(IDC_TESTBUTTON, &CStuInfoSystemDlg::OnBnClickedTestbutton)
	ON_BN_CLICKED(IDC_BOOKBUTTON, &CStuInfoSystemDlg::OnBnClickedBookbutton)
END_MESSAGE_MAP()


// CStuInfoSystemDlg 消息处理程序

BOOL CStuInfoSystemDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	m_list.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);// 整行选择、网格线
	m_list.InsertColumn(0, _T("姓名"), LVCFMT_LEFT, 105);
	m_list.InsertColumn(1, _T("性别"), LVCFMT_LEFT, 105);
	m_list.InsertColumn(2, _T("班级"), LVCFMT_LEFT, 105);
	m_list.InsertColumn(3, _T("英语"), LVCFMT_LEFT, 105);
	m_list.InsertColumn(4, _T("语文"), LVCFMT_LEFT, 105);
	m_list.InsertColumn(5, _T("数学"), LVCFMT_LEFT, 105);

	m_class.AddString(TEXT("1班"));
	m_class.AddString(TEXT("2班"));
	m_class.AddString(TEXT("3班"));
	m_class.AddString(TEXT("全部"));
	m_class.SetCurSel(3);

	m_subject.AddString(TEXT("英语"));
	m_subject.AddString(TEXT("语文"));
	m_subject.AddString(TEXT("数学"));
	m_subject.SetCurSel(0);

	m_rule1.AddString(TEXT("班级"));
	m_rule1.AddString(TEXT("英语"));
	m_rule1.AddString(TEXT("语文"));
	m_rule1.AddString(TEXT("数学"));
	m_rule1.SetCurSel(0);

	m_rule2.AddString(TEXT("升序"));
	m_rule2.AddString(TEXT("降序"));
	m_rule2.SetCurSel(0);

	flag = false;
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

bool CStuInfoSystemDlg::flag = false;

void CStuInfoSystemDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CStuInfoSystemDlg::OnPaint()
{
	//if (IsIconic())
	//{
	//	CPaintDC dc(this); // 用于绘制的设备上下文

	//	SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

	//	// 使图标在工作区矩形中居中
	//	int cxIcon = GetSystemMetrics(SM_CXICON);
	//	int cyIcon = GetSystemMetrics(SM_CYICON);
	//	CRect rect;
	//	GetClientRect(&rect);
	//	int x = (rect.Width() - cxIcon + 1) / 2;
	//	int y = (rect.Height() - cyIcon + 1) / 2;

	//	// 绘制图标
	//	dc.DrawIcon(x, y, m_hIcon);
	//}
	//else
	//{
	//	CDialogEx::OnPaint();
	//}

	CPaintDC dc(this);//用于画图的设备上下文  
	//加载背景位图  
	CBitmap bitmap;
	bitmap.LoadBitmap(IDB_BITMAP1);
	CBrush brush(&bitmap);//建立画刷  
	dc.SetBkMode(TRANSPARENT);
	dc.SelectObject(brush);
	CRect rect;
	GetClientRect(rect);//获得客户区大小  
	dc.Rectangle(rect);//画矩形，并用图片的画刷填充

	/*CClientDC cdc(this); CDC comdc;
	comdc.CreateCompatibleDC(&cdc);
	CBitmap bitmap;
	bitmap.LoadBitmap(IDB_BITMAP1);
	comdc.SelectObject(&bitmap);
	cdc.SetBkMode(TRANSPARENT);
	CRect rect;
	GetClientRect(rect);
	BITMAP bit;
	bitmap.GetBitmap(&bit);
	cdc.StretchBlt(0, 0, rect.Width(), rect.Height(), &comdc, 0, 0, bit.bmWidth, bit.bmHeight, SRCCOPY);*/
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CStuInfoSystemDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CStuInfoSystemDlg::OnBnClickedInputdata()
{
	// TODO: 在此添加控件通知处理程序代码
	if (SQL.Connect_MySQL()) {
		Info = SQL.Get_All_Info();
		//MessageBox(TEXT("heheda 是个大笨蛋!"));
		UpdateList();
	}
	else {
		return;
	}
}

void CStuInfoSystemDlg::OnBnClickedInsertdata()
{
	// TODO: 在此添加控件通知处理程序代码
	InfoDlg dlg;
	if (dlg.DoModal() == IDOK) {
		if (SQL.Add_Info(StuInfo(dlg.m_name.GetBuffer(), dlg.m_sex.GetBuffer(), dlg.m_class, dlg.m_english, dlg.m_chinese, dlg.m_math)))
		{
			MessageBox(TEXT("添加成功!"),TEXT("提示"));
			Info.push_back(StuInfo(dlg.m_name.GetBuffer(), dlg.m_sex.GetBuffer(), dlg.m_class, dlg.m_english, dlg.m_chinese, dlg.m_math));
			UpdateList();
		}
	}	
}

void CStuInfoSystemDlg::UpdateList()
{
	CString str;
	m_list.DeleteAllItems();
	for (int i = 0; i < Info.size(); i++) {
		m_list.InsertItem(i, Info[i].m_name.c_str());
		m_list.SetItemText(i, 1, Info[i].m_sex.c_str());

		str.Format(TEXT("%d"), Info[i].m_class_);
		m_list.SetItemText(i, 2, str);

		str.Format(TEXT("%.1f"), Info[i].m_english);
		m_list.SetItemText(i, 3, str);

		str.Format(TEXT("%.1f"), Info[i].m_chinese);
		m_list.SetItemText(i, 4, str);

		str.Format(TEXT("%.1f"), Info[i].m_math);
		m_list.SetItemText(i, 5, str);
	}
}


void CStuInfoSystemDlg::OnBnClickedDeldata()
{
	// TODO: 在此添加控件通知处理程序代码
	int nIndex = m_list.GetSelectionMark(); // 获取选中行的行号
	if (nIndex == -1) {
		MessageBox(TEXT("请先选择要删除的数据!"),TEXT("提示"));
		return;
	}
	else {
		UINT i;
		i = MessageBox(_T("确认要删除这条信息吗？"), _T("提示"), MB_YESNO | MB_ICONQUESTION);
		if (i == IDYES) {
			if (SQL.Del_Info(Info[nIndex])) {
				MessageBox(TEXT("删除成功!"), TEXT("提示"));
				Info.erase(Info.begin() + nIndex);
				UpdateList();
			}
		}
	}
}


void CStuInfoSystemDlg::OnBnClickedModifydata()
{
	// TODO: 在此添加控件通知处理程序代码
	int nIndex = m_list.GetSelectionMark(); // 获取选中行的行号
	if (nIndex == -1) {
		MessageBox(TEXT("请先选择要修改的数据!"), TEXT("提示"));
		return;
	}
	else {
		InfoDlg dlg;
		dlg.m_name = Info[nIndex].m_name.c_str();
		dlg.m_sex = Info[nIndex].m_sex.c_str();
		dlg.m_class = Info[nIndex].m_class_;
		dlg.m_english = Info[nIndex].m_english;
		dlg.m_chinese = Info[nIndex].m_chinese;
		dlg.m_math = Info[nIndex].m_math;
		if (dlg.DoModal() == IDOK) {
			if (SQL.Update_Info(Info[nIndex], StuInfo(dlg.m_name.GetBuffer(), dlg.m_sex.GetBuffer(), dlg.m_class, dlg.m_english, dlg.m_chinese, dlg.m_math))) {
				MessageBox(TEXT("修改成功!"), TEXT("提示"));
				Info[nIndex] = StuInfo(dlg.m_name.GetBuffer(), dlg.m_sex.GetBuffer(), dlg.m_class, dlg.m_english, dlg.m_chinese, dlg.m_math);
				UpdateList();
			}
		}
	}
}


void CStuInfoSystemDlg::OnBnClickedFinddata()
{
	// TODO: 在此添加控件通知处理程序代码
	SeekDlg dlg;
	if (dlg.DoModal() == IDOK) {
		vector<StuInfo> result = SQL.SeekInfo(dlg.m_name);
		if (result.empty()) {
			MessageBox(TEXT("查无此人!"), TEXT("提示"));
			return;
		}
		CString str;
		m_list.DeleteAllItems();
		for (int i = 0; i < result.size(); i++) {
			m_list.InsertItem(i, result[i].m_name.c_str());
			m_list.SetItemText(i, 1, result[i].m_sex.c_str());

			str.Format(TEXT("%d"), result[i].m_class_);
			m_list.SetItemText(i, 2, str);

			str.Format(TEXT("%.1f"), result[i].m_english);
			m_list.SetItemText(i, 3, str);

			str.Format(TEXT("%.1f"), result[i].m_chinese);
			m_list.SetItemText(i, 4, str);

			str.Format(TEXT("%.1f"), result[i].m_math);
			m_list.SetItemText(i, 5, str);
		}
	}
}


void CStuInfoSystemDlg::OnBnClickedCalculatebutton()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData(TRUE);
	int num = 0;
	double sum = 0;
	double highScore = 0;
	double lowScore = 100;
	int pass = 0;

	int curClass = m_class.GetCurSel();
	int curSubject = m_subject.GetCurSel();
	vector<double> selectedScore;
	for (int i = 0; i < Info.size(); i++) {
		if (Info[i].m_class_ == curClass + 1 || curClass == 3) {
			switch (curSubject) { // 统计科目
			case 0:
				selectedScore.push_back(Info[i].m_english); // 英语
				break;
			case 1:
				selectedScore.push_back(Info[i].m_chinese); // 语文
				break;
			case 2:
				selectedScore.push_back(Info[i].m_math);    // 数学
				break;
			default:
				break;
			}
		}
	}
	//MessageBox(TEXT("查无此人!"), TEXT("提示"));
	for (int i = 0; i < selectedScore.size(); i++) {
		sum += selectedScore[i];
		highScore = max(highScore, selectedScore[i]);
		lowScore = min(lowScore, selectedScore[i]);
		if (selectedScore[i] >= 60) pass++;
	}
	num = selectedScore.size();
	m_avg.Format(TEXT("%.2lf"), sum / num);
	m_pass.Format(TEXT("%.2lf"), pass * 1.0 / num);
	m_high = highScore;
	m_low = lowScore;

	UpdateData(FALSE);
}

bool CStuInfoSystemDlg::cmp_by_class(StuInfo a,StuInfo b) {
	if(flag == false) return a.m_class_ < b.m_class_;
	else return a.m_class_ > b.m_class_;
}

bool CStuInfoSystemDlg::cmp_by_english(StuInfo a, StuInfo b) {
	if (flag == false) return a.m_english < b.m_english;
	else return a.m_english > b.m_english;
}

bool CStuInfoSystemDlg::cmp_by_chinese(StuInfo a, StuInfo b) {
	if (flag == false) return a.m_chinese < b.m_chinese;
	else return a.m_chinese > b.m_chinese;
}

bool CStuInfoSystemDlg::cmp_by_math(StuInfo a, StuInfo b) {
	if (flag == false) return a.m_math < b.m_math;
	else return a.m_math > b.m_math;
}

void CStuInfoSystemDlg::OnCbnSelchangeSortcombo1()
{
	// TODO: 在此添加控件通知处理程序代码
	int nIndex = m_rule1.GetCurSel();
	if (nIndex == 0) sort(Info.begin(), Info.end(), cmp_by_class);
	if (nIndex == 1) sort(Info.begin(), Info.end(), cmp_by_english);
	if (nIndex == 2) sort(Info.begin(), Info.end(), cmp_by_chinese);
	if (nIndex == 3) sort(Info.begin(), Info.end(), cmp_by_math);
	UpdateList();
}


void CStuInfoSystemDlg::OnCbnSelchangeSortcombo2()
{
	// TODO: 在此添加控件通知处理程序代码
	int nIndex = m_rule2.GetCurSel();
	if (nIndex == 0) flag = false; // 升序
	else flag = true; // 倒序

	nIndex = m_rule1.GetCurSel();
	if (nIndex == 0) sort(Info.begin(), Info.end(), cmp_by_class);
	if (nIndex == 1) sort(Info.begin(), Info.end(), cmp_by_english);
	if (nIndex == 2) sort(Info.begin(), Info.end(), cmp_by_chinese);
	if (nIndex == 3) sort(Info.begin(), Info.end(), cmp_by_math);
	UpdateList();
}


void CStuInfoSystemDlg::OnBnClickedExit()
{
	// TODO: 在此添加控件通知处理程序代码
	UINT i;
	i = MessageBox(_T("确认要退出吗?"), _T("提示"), MB_YESNO | MB_ICONQUESTION);
	if (i == IDYES) {
		// 关闭数据库
		SQL.Close_MYSQL();
		exit(0);
	}
}

/*添加背景图片*/
BOOL CStuInfoSystemDlg::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	CDialog::OnEraseBkgnd(pDC);
	HBITMAP   m_hBitmap;
	HDC           m_hBkDC;
	m_hBitmap = ::LoadBitmap(::GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_BITMAP1));
	m_hBkDC = ::CreateCompatibleDC(pDC->m_hDC);
	if (m_hBitmap && m_hBkDC)
	{
		::SelectObject(m_hBkDC, m_hBitmap);
		::StretchBlt(pDC->m_hDC, 0, 0, 700, 610, m_hBkDC, 0, 0, 700, 610, SRCCOPY);
		::DeleteObject(m_hBitmap);
		::DeleteDC(m_hBkDC);
	}
	return TRUE;
}

/*设置控件背景透明*/
HBRUSH CStuInfoSystemDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	if (nCtlColor == CTLCOLOR_STATIC)
	{
		pDC->SetBkMode(TRANSPARENT);//设置背景透明
		pDC->SetTextColor(RGB(255, 255, 0));//设置字体为黄色
		return (HBRUSH)::GetStockObject(NULL_BRUSH);
	}

	// TODO:  如果默认的不是所需画笔，则返回另一个画笔
	return hbr;
}

void CStuInfoSystemDlg::OnBnClickedTestbutton()
{
	// TODO: 在此添加控件通知处理程序代码
	TestDialog dlg;
	if (dlg.DoModal() == IDOK) {
		MessageBox(TEXT("添加成功!"), TEXT("提示"));
	}
}


void CStuInfoSystemDlg::OnBnClickedBookbutton()
{
	// TODO: 在此添加控件通知处理程序代码
	BOOK dlg;
	if (dlg.DoModal() == IDOK) {
		MessageBox(TEXT("添加成功!"), TEXT("提示"));
	}
}
