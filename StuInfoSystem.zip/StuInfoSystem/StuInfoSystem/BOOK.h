﻿#pragma once
#include "afxdialogex.h"
#include "SQLInterface.h"

// BOOK 对话框

class BOOK : public CDialogEx
{
	DECLARE_DYNAMIC(BOOK)

public:
	BOOK(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~BOOK();
	SQLInterface SQL;
	vector<StuInfo> Info;
	void UpdateList();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_BOOK };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedConnbutton();
};
